import * as THREE from "three";
import { configManager } from "../core/ConfigManager.js";

/**
 * AudioManager
 * -----------------------------------------------------------------------
 * Основа майбутньої аудіосистеми (дощ, атмосфера, звукові ефекти).
 * На цьому етапі жоден звук не завантажується і не відтворюється.
 */
export class AudioManager {
  /**
   * @param {THREE.Camera} camera Аудіо-слухач кріпиться до камери.
   */
  constructor(camera) {
    this.config = configManager.get("audio");

    this.listener = new THREE.AudioListener();
    camera.add(this.listener);

    this.sounds = new Map();
    this.muted = this.config.muted;
    this.masterVolume = this.config.masterVolume;
  }

  /**
   * Зареєструвати звук у системі (без відтворення). Заготовка на майбутнє.
   * @param {string} id
   * @param {AudioBuffer} buffer
   * @param {{ loop?: boolean, volume?: number }} options
   */
  registerSound(id, buffer, options = {}) {
    const sound = new THREE.Audio(this.listener);
    sound.setBuffer(buffer);
    sound.setLoop(options.loop ?? false);
    sound.setVolume((options.volume ?? 1) * this.masterVolume);

    this.sounds.set(id, sound);
    return sound;
  }

  setMasterVolume(value) {
    this.masterVolume = value;
    this.sounds.forEach((sound) => sound.setVolume(value));
  }

  setMuted(muted) {
    this.muted = muted;
    this.listener.setMasterVolume(muted ? 0 : this.masterVolume);
  }
}
