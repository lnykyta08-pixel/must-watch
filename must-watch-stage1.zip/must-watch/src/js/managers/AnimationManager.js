import gsap from "gsap";
import { configManager } from "../core/ConfigManager.js";

/**
 * AnimationManager
 * -----------------------------------------------------------------------
 * Централізована обгортка над GSAP та рендер-циклом.
 *
 * Усі майбутні анімації (журнал, дощ, камера, UI) мають реєструватися
 * через цей менеджер, щоб уникнути розкиданих по проєкту requestAnimationFrame.
 */
export class AnimationManager {
  constructor() {
    this.defaults = configManager.get("animation");
    gsap.defaults({
      ease: this.defaults.defaultEase,
      duration: this.defaults.defaultDuration,
    });

    this._tickCallbacks = new Set();
    this._clock = gsap.ticker;
    this._isRunning = false;

    this._onTick = this._onTick.bind(this);
  }

  /**
   * Підписати функцію на кожен кадр (наприклад, рендер сцени).
   * @param {(time: number, deltaTime: number) => void} callback
   */
  onTick(callback) {
    this._tickCallbacks.add(callback);
    return () => this._tickCallbacks.delete(callback);
  }

  start() {
    if (this._isRunning) return;
    this._isRunning = true;
    this._clock.add(this._onTick);
  }

  stop() {
    if (!this._isRunning) return;
    this._isRunning = false;
    this._clock.remove(this._onTick);
  }

  _onTick(time, deltaTime) {
    this._tickCallbacks.forEach((callback) => callback(time, deltaTime));
  }

  /**
   * Прямий доступ до gsap.timeline() для складних послідовностей анімацій.
   */
  createTimeline(vars = {}) {
    return gsap.timeline(vars);
  }
}
