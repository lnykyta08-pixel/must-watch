import * as THREE from "three";
import { configManager } from "../core/ConfigManager.js";

/**
 * RendererManager
 * -----------------------------------------------------------------------
 * Відповідає лише за WebGL-рендерер: створення, масштабування під екран
 * (включно з Retina) та реакцію на зміну розміру вікна.
 */
export class RendererManager {
  /**
   * @param {HTMLCanvasElement} canvas
   */
  constructor(canvas) {
    this.canvas = canvas;
    this.config = configManager.get("renderer");

    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: this.config.antialias,
      alpha: this.config.alpha,
      powerPreference: this.config.powerPreference,
    });

    this._configureRenderer();
    this._bindResize();
  }

  _configureRenderer() {
    const pixelRatio = Math.min(window.devicePixelRatio || 1, this.config.maxPixelRatio);

    this.renderer.setPixelRatio(pixelRatio);
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    this.renderer.setClearColor(this.config.clearColor);
    this.renderer.shadowMap.enabled = this.config.shadowMapEnabled;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = this.config.toneMappingExposure;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
  }

  _bindResize() {
    this._onResize = this._onResize.bind(this);
    window.addEventListener("resize", this._onResize);
  }

  _onResize() {
    const width = window.innerWidth;
    const height = window.innerHeight;
    const pixelRatio = Math.min(window.devicePixelRatio || 1, this.config.maxPixelRatio);

    this.renderer.setPixelRatio(pixelRatio);
    this.renderer.setSize(width, height, false);

    if (this.onResizeCallback) {
      this.onResizeCallback(width, height);
    }
  }

  /**
   * Дозволяє іншим менеджерам (наприклад, CameraManager) підписатись
   * на подію зміни розміру вікна.
   * @param {(width: number, height: number) => void} callback
   */
  onResize(callback) {
    this.onResizeCallback = callback;
  }

  render(scene, camera) {
    this.renderer.render(scene, camera);
  }

  dispose() {
    window.removeEventListener("resize", this._onResize);
    this.renderer.dispose();
  }
}
