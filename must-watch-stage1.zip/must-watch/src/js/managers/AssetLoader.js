import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { configManager } from "../core/ConfigManager.js";

/**
 * AssetLoader
 * -----------------------------------------------------------------------
 * Основа майбутньої системи завантаження ресурсів: моделей, текстур,
 * звуків, постерів і шрифтів.
 *
 * На цьому етапі нічого фактично не завантажується — лише підготовлені
 * внутрішні loader-и та кеш, готові до використання на наступних етапах.
 */
export class AssetLoader {
  constructor() {
    this.basePaths = configManager.get("assets.basePaths");

    this.cache = {
      models: new Map(),
      textures: new Map(),
      audio: new Map(),
      posters: new Map(),
    };

    this._gltfLoader = new GLTFLoader();
    this._textureLoader = new THREE.TextureLoader();
    this._audioLoader = new THREE.AudioLoader();

    this._loadingManager = new THREE.LoadingManager();
  }

  /**
   * Завантажити 3D-модель (.glb/.gltf). Заготовка на майбутнє.
   * @param {string} fileName
   * @returns {Promise<Object>}
   */
  loadModel(fileName) {
    if (this.cache.models.has(fileName)) {
      return Promise.resolve(this.cache.models.get(fileName));
    }

    const url = `${this.basePaths.models}${fileName}`;

    return new Promise((resolve, reject) => {
      this._gltfLoader.load(
        url,
        (gltf) => {
          this.cache.models.set(fileName, gltf);
          resolve(gltf);
        },
        undefined,
        reject
      );
    });
  }

  /**
   * Завантажити текстуру. Заготовка на майбутнє.
   * @param {string} fileName
   * @returns {Promise<THREE.Texture>}
   */
  loadTexture(fileName) {
    if (this.cache.textures.has(fileName)) {
      return Promise.resolve(this.cache.textures.get(fileName));
    }

    const url = `${this.basePaths.textures}${fileName}`;

    return new Promise((resolve, reject) => {
      this._textureLoader.load(
        url,
        (texture) => {
          this.cache.textures.set(fileName, texture);
          resolve(texture);
        },
        undefined,
        reject
      );
    });
  }

  /**
   * Завантажити аудіофайл. Заготовка на майбутнє.
   * @param {string} fileName
   * @returns {Promise<AudioBuffer>}
   */
  loadAudio(fileName) {
    if (this.cache.audio.has(fileName)) {
      return Promise.resolve(this.cache.audio.get(fileName));
    }

    const url = `${this.basePaths.audio}${fileName}`;

    return new Promise((resolve, reject) => {
      this._audioLoader.load(
        url,
        (buffer) => {
          this.cache.audio.set(fileName, buffer);
          resolve(buffer);
        },
        undefined,
        reject
      );
    });
  }

  clearCache() {
    this.cache.models.clear();
    this.cache.textures.clear();
    this.cache.audio.clear();
    this.cache.posters.clear();
  }
}
