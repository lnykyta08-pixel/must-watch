import * as THREE from "three";
import { configManager } from "../core/ConfigManager.js";

/**
 * CameraManager
 * -----------------------------------------------------------------------
 * Відповідає лише за камеру: створення та адаптацію aspect ratio
 * при зміні розміру вікна. Усі параметри беруться з ConfigManager,
 * жодних захардкоджених значень.
 */
export class CameraManager {
  constructor() {
    this.config = configManager.get("camera");

    this.camera = new THREE.PerspectiveCamera(
      this.config.fov,
      window.innerWidth / window.innerHeight,
      this.config.near,
      this.config.far
    );

    this._applyInitialTransform();
  }

  _applyInitialTransform() {
    const { position, lookAt } = this.config;
    this.camera.position.set(position.x, position.y, position.z);
    this.camera.lookAt(lookAt.x, lookAt.y, lookAt.z);
  }

  /**
   * Викликається при зміні розміру вікна, щоб уникнути спотворення картинки.
   * @param {number} width
   * @param {number} height
   */
  updateAspect(width, height) {
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
  }
}
