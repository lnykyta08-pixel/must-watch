/**
 * UIManager
 * -----------------------------------------------------------------------
 * Відповідає за DOM-шар інтерфейсу поверх 3D-сцени.
 *
 * На цьому етапі UI не реалізується — лише підготовлений контейнер
 * (.ui-layer), до якого на наступних етапах будуть додаватися
 * компоненти (журнал, підказки, меню тощо).
 */
export class UIManager {
  constructor(root = document.getElementById("app")) {
    this.root = root;
    this.layer = null;
  }

  init() {
    this.layer = document.createElement("div");
    this.layer.className = "ui-layer";
    this.root.appendChild(this.layer);
    return this.layer;
  }

  mount(element) {
    if (!this.layer) this.init();
    this.layer.appendChild(element);
  }

  clear() {
    if (this.layer) {
      this.layer.innerHTML = "";
    }
  }
}
