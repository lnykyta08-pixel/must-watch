import * as THREE from "three";
import { configManager } from "../core/ConfigManager.js";

/**
 * SceneManager
 * -----------------------------------------------------------------------
 * Відповідає лише за THREE.Scene. На цьому етапі сцена навмисно порожня —
 * кімната, стіл, журнал та освітлення будуть додані на наступних етапах.
 */
export class SceneManager {
  constructor() {
    this.config = configManager.get("scene");

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(this.config.backgroundColor);

    if (this.config.fogEnabled) {
      this.scene.fog = new THREE.Fog(
        this.config.fogColor,
        this.config.fogNear,
        this.config.fogFar
      );
    }
  }

  add(object) {
    this.scene.add(object);
  }

  remove(object) {
    this.scene.remove(object);
  }
}
