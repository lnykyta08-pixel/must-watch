/**
 * ConfigManager
 * -----------------------------------------------------------------------
 * Єдине централізоване джерело налаштувань проєкту.
 *
 * Жоден модуль не повинен захардкоджувати параметри камери, рендерера
 * чи інші глобальні константи — усе має братися звідси. Це дозволяє
 * змінювати поведінку проєкту в одному місці на майбутніх етапах.
 */

class ConfigManager {
  constructor() {
    this.config = {
      app: {
        name: "Must-Watch",
        debug: false,
      },

      renderer: {
        antialias: true,
        alpha: false,
        powerPreference: "high-performance",
        // Обмежуємо pixel ratio, щоб не перевантажувати Retina/4K екрани.
        maxPixelRatio: 2,
        clearColor: 0x05060a,
        toneMappingExposure: 1.0,
        shadowMapEnabled: true,
      },

      camera: {
        fov: 45,
        near: 0.1,
        far: 1000,
        position: { x: 0, y: 1.6, z: 6 },
        lookAt: { x: 0, y: 1.2, z: 0 },
      },

      scene: {
        backgroundColor: 0x05060a,
        fogEnabled: false,
        fogColor: 0x05060a,
        fogNear: 1,
        fogFar: 50,
      },

      assets: {
        basePaths: {
          models: "/src/assets/models/",
          textures: "/src/assets/textures/",
          audio: "/src/assets/audio/",
          posters: "/src/assets/posters/",
          fonts: "/src/assets/fonts/",
        },
      },

      data: {
        // Джерело даних про фільми буде додано на наступних етапах.
        basePath: "/src/js/data/json/",
      },

      animation: {
        defaultEase: "power2.out",
        defaultDuration: 0.8,
      },

      audio: {
        masterVolume: 0.8,
        muted: false,
      },
    };
  }

  /**
   * Отримати значення налаштування за шляхом типу "camera.fov".
   * @param {string} path
   * @returns {*}
   */
  get(path) {
    return path
      .split(".")
      .reduce((value, key) => (value ? value[key] : undefined), this.config);
  }

  /**
   * Оновити значення налаштування в рантаймі (наприклад, з UI налаштувань).
   * @param {string} path
   * @param {*} value
   */
  set(path, value) {
    const keys = path.split(".");
    const lastKey = keys.pop();
    const target = keys.reduce((acc, key) => acc[key], this.config);
    target[lastKey] = value;
  }
}

// Єдиний спільний екземпляр на весь застосунок (singleton).
export const configManager = new ConfigManager();
