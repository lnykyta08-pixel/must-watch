import { SceneManager } from "../managers/SceneManager.js";
import { CameraManager } from "../managers/CameraManager.js";
import { RendererManager } from "../managers/RendererManager.js";
import { AssetLoader } from "../managers/AssetLoader.js";
import { UIManager } from "../managers/UIManager.js";
import { AudioManager } from "../managers/AudioManager.js";
import { AnimationManager } from "../managers/AnimationManager.js";
import { configManager } from "./ConfigManager.js";

/**
 * App
 * -----------------------------------------------------------------------
 * Головна точка збірки проєкту. Створює всі менеджери та з'єднує їх
 * між собою. На цьому етапі сцена порожня — кімната, стіл, журнал,
 * освітлення та моделі будуть додані на наступних етапах.
 */
export class App {
  /**
   * @param {HTMLCanvasElement} canvas
   */
  constructor(canvas) {
    this.config = configManager;

    this.sceneManager = new SceneManager();
    this.cameraManager = new CameraManager();
    this.rendererManager = new RendererManager(canvas);
    this.assetLoader = new AssetLoader();
    this.uiManager = new UIManager();
    this.audioManager = new AudioManager(this.cameraManager.camera);
    this.animationManager = new AnimationManager();

    this._connectManagers();
  }

  _connectManagers() {
    // Камера має підлаштовуватись під розмір при ресайзі рендерера.
    this.rendererManager.onResize((width, height) => {
      this.cameraManager.updateAspect(width, height);
    });

    // Рендер сцени відбувається на кожному тіку центрального аніматора.
    this.animationManager.onTick(() => {
      this.rendererManager.render(this.sceneManager.scene, this.cameraManager.camera);
    });
  }

  start() {
    this.uiManager.init();
    this.animationManager.start();
  }

  dispose() {
    this.animationManager.stop();
    this.rendererManager.dispose();
  }
}
