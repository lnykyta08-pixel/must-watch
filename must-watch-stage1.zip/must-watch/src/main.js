import "./css/main.css";
import { App } from "./js/core/App.js";

const canvas = document.getElementById("scene-canvas");
const app = new App(canvas);

app.start();

// Доступно в консолі для швидкої діагностики під час розробки.
if (import.meta.env.DEV) {
  window.__MUST_WATCH_APP__ = app;
}
